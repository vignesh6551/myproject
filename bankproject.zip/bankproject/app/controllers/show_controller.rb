class ShowController < ApplicationController
  def deposit
  end
end
