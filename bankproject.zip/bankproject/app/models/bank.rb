class Bank < ApplicationRecord
end
