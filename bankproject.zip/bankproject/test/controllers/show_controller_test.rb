require "test_helper"

class ShowControllerTest < ActionDispatch::IntegrationTest
  test "should get deposit" do
    get show_deposit_url
    assert_response :success
  end
end
