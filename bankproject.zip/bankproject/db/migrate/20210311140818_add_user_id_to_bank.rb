class AddUserIdToBank < ActiveRecord::Migration[6.1]
  def change
    add_column :banks, :user_id, :integer
  end
end
